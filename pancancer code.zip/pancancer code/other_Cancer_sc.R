library(Seurat)
library(Matrix)
library(pheatmap)
library(plyr)
library(data.table)
library(patchwork)
library(dplyr)
library(ggplot2)
setwd("/export/home/lileijie/pan_cancer/other_tumor/result_all")
########### osteosarcoma dota collection #################################################################################
sample<-list.dirs("/export/home/lileijie/pan_cancer/other_tumor/osteosarcoma")[-1]                                      ##
oc_label_all<-"0"                                                                                                       ##
for (i in 1:length(sample)){                                                                                            ##
  print(i)                                                                                                              ##
  label<-tail(strsplit(sample[i],"/")[[1]],1)                                                                           ##
  oc_label_all<-c(oc_label_all,label)                                                                                   ##
  ostc <- Read10X(data.dir = sample[i])                                                                                 ##
  ostc <- CreateSeuratObject(counts = ostc, min.cells = 3, min.features = 300, project = label)                         ##
  ostc@meta.data$tech<-"10xseq"                                                                                         ##
  ostc[["percent.mt"]] <- PercentageFeatureSet(ostc, pattern = "^MT-")                                                  ##
  #pdf(file = paste(label,".pdf",sep = ""),width = 10,height = 10)                                                      ##
  #print(VlnPlot(object = ostc, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3))                    ##
  #dev.off()                                                                                                            ##
  ostc <- subset(x = ostc, subset = nFeature_RNA > 200 & nFeature_RNA < 5000 & percent.mt < 20)                         ##
  ostc@meta.data$study=label                                                                                            ##
  eval(parse(text = paste("ostc",i,"<-ostc",sep = "")))                                                                 ##
}                                                                                                                       ##
oc_label_all<-oc_label_all[-1]                                                                                          ##
oc_label_all<-gsub("BC","ostc",oc_label_all)                                                                            ##
ostc_all<-merge(x=ostc1,y=c(ostc2,ostc3,ostc4,ostc5,ostc6,ostc7,ostc8,ostc9,ostc10,ostc11),add.cell.ids=oc_label_all)   ##
now<-levels(ostc_all@active.ident)                                                                                      ##
new<-gsub("BC","OSTC",now)                                                                                              ##
ostc_all@active.ident<-plyr::mapvalues(x=ostc_all@active.ident, from=now, to=new)                                       ##
#oc_label_all2<-oc_label_all[-c(1,2,10)]                                                                                ##
#ostc_all<-merge(x=ostc3,y=c(ostc4,ostc5,ostc6,ostc7,ostc8,ostc9,ostc11),add.cell.ids=oc_label_all2)                    ##
ostc_all$study<-"gse152048"                                                                                             ##
ostc_all@meta.data$sample<-as.matrix(ostc_all@active.ident)                                                             ##
##########################################################################################################################
########### breastcancer #################################################################################################
# two data                                                                                                              ##
bc_data1<-"/export/home/lileijie/pan_cancer/other_tumor/breastcancer/blueprint" #seurat                                 ##
bc_data2<-"/export/home/lileijie/pan_cancer/other_tumor/breastcancer/GSE75688" #matrix                                  ##
bc1 <- Read10X(data.dir = bc_data1)                                                                                     ##
bc1 <- CreateSeuratObject(counts = bc1, min.cells = 3, min.features = 300, project = label)                             ##
bc1@meta.data$tech<-"10xseq"                                                                                            ##
bc1[["percent.mt"]] <- PercentageFeatureSet(bc1, pattern = "^MT-")                                                      ##
pdf(file = "bc1.pdf",width = 10,height = 10)                                                                            ##
print(VlnPlot(object = bc1, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3))                        ##
dev.off()                                                                                                               ##
bc1 <- subset(x = bc1, subset = nFeature_RNA > 200 & nFeature_RNA < 5000 & percent.mt < 20)                             ##
bc1@meta.data$study="blueprint"                                                                                         ##
bc_label_all<-"blueprint"                                                                                               ##
bc2_data<-read.table(paste(bc_data2,"/GSE75688_BC410_TPM_matrix.txt",sep = ""),sep="\t",header = T,row.names = "gene_id")#
bc2_name.list<-bc2_data$gene_name[duplicated(bc2_data$gene_name)]                                                       ##
for (i in 1:length(bc2_name.list)) {                                                                                    ##
  index<-bc2_data$gene_name==bc2_name.list[i]                                                                           ##
  bc2_data[index[i],2:ncol(bc2_data)]<-colSums(bc2_data[index,2:ncol(bc2_data)])                                        ##
  print(i)                                                                                                              ##
}                                                                                                                       ##
bc2_data<-bc2_data[!duplicated(bc2_data$gene_name),]                                                                    ##
rownames(bc2_data)<-bc2_data$gene_name                                                                                  ##
bc2_data<-bc2_data[,-1]                                                                                                 ##
bc2_meta<-read.table(paste(bc_data2,"/meta.txt",sep = ""),sep="\t",header = T,row.names = "Cell_name")                  ##
bc2<-CreateSeuratObject(counts = bc2_data,min.cells = 5,min.features = 200,meta.data =bc2_meta,project = "GSE75688")    ##
bc2@meta.data$study<-"gse75688"                                                                                         ##
bc_all<-merge(x=bc1,y=bc2)                                                                                              ##
bc_all@meta.data$sample<-bc_all@active.ident                                                                            ##
##########################################################################################################################
######## melanoma ########################################################################################################
mela1<-"/export/home/lileijie/pan_cancer/other_tumor/melanoma/GSE72056"                                                 ##
mela1_data<-read.table(paste(mela1,"/GSE72056_melanoma.txt",sep = ""),sep="\t",header = T)                              ##
mela1_name.list<-mela1_data$Cell[duplicated(mela1_data$Cell)]                                                           ##
for (i in 1:length(mela1_name.list)) {                                                                                  ##
  index<-mela1_data$Cell==mela1_name.list[i]                                                                            ##
  mela1_data[index[i],2:ncol(mela1_data)]<-colSums(mela1_data[index,2:ncol(mela1_data)])                                ##
}                                                                                                                       ##
mela1_data<-mela1_data[!duplicated(mela1_data$Cell),]                                                                   ##
rownames(mela1_data)<-mela1_data$Cell                                                                                   ##
mela1_data<-mela1_data[,-1]                                                                                             ##
mela1_meta<-read.table(paste(mela1,"/melanoma_meta.txt",sep = ""),sep="\t",header = T,row.names = "Cell_name")          ##
mela1<-CreateSeuratObject(counts = mela1_data,min.cells = 5,min.features = 200,meta.data =mela1_meta,project = "GSE72056")
mela1$study<-"gse72056"                                                                                                 ##
mela1@meta.data$sample<-mela1$study                                                                                     ##
##########################################################################################################################
########## Ovarian cancer ################################################################################################
ovc_dir<-"/export/home/lileijie/pan_cancer/other_tumor/ovariancancer/blueprint"                                         ##
ovc <- Read10X(data.dir = ovc_dir)                                                                                      ##
ovc <- CreateSeuratObject(counts = ovc, min.cells = 3, min.features = 300, project = "blueprint")                       ##
ovc@meta.data$tech<-"10xseq"                                                                                            ##
ovc[["percent.mt"]] <- PercentageFeatureSet(ovc, pattern = "^MT-")                                                      ##
pdf(file = "ovc.pdf",width = 10,height = 10)                                                                            ##
print(VlnPlot(object = ovc, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3))                        ##
dev.off()                                                                                                               ##
ovc <- subset(x = ovc, subset = nFeature_RNA > 200 & nFeature_RNA < 5000 & percent.mt < 20)                             ##
ovc@meta.data$study="blueprint"                                                                                         ##
ovc@meta.data$sample=as.matrix(ovc@active.ident)                                                                        ##
##########################################################################################################################
########### Stellate cell carcinoma ######################################################################################
scc_dir<-"/export/home/lileijie/pan_cancer/other_tumor/Stellate_cell_carcinoma"                                         ##
scc_data<-read.table(paste(scc_dir,"/GSE89567_SCC.txt",sep = ""),sep="\t",header = T,row.names = "gene_name")           ##
scc_meta<-read.table(paste(scc_dir,"/GSE89567_meta.txt",sep=""),sep="\t",header = T,row.names = "Cell_name")            ##
scc<-CreateSeuratObject(counts = scc_data,min.cells = 5,min.features = 200,meta.data =scc_meta,project = "GSE89567")    ##
scc@meta.data$study<-"gse89567"                                                                                         ##
### sample                                                                                                              ##
scc.namelist<-names(scc$study)                                                                                          ##
scc.samplelist<-scc.namelist                                                                                            ##
for (i in 1:length(scc.namelist)) {                                                                                     ##
  scc.samplelist[i]<-strsplit(scc.namelist[i],"_")[[1]][1]                                                              ##
  scc.samplelist[i]<-strsplit(scc.samplelist[i],"\\.")[[1]][1]                                                          ##
}                                                                                                                       ##
scc.samplelist<-plyr::mapvalues(x = scc.samplelist, from = c("mgh103","MGH107neg","MGH107pos","X57"),                   ##
                                to = c("MGH103","MGH107","MGH107","MGH57"))                                             ##
names(scc.samplelist)<-names(scc$study)                                                                                 ##
scc@meta.data$sample<-scc.samplelist                                                                                    ##
##########################################################################################################################
########## glioma ########################################################################################################
glm_dir<-"/export/home/lileijie/pan_cancer/other_tumor/glioma/glioma_GSE84465"                                          ##
glm_data<-read.table(paste(glm_dir,"/GSE84465_glioma.txt",sep = ""),sep=",",header = T,row.names = "gene_name")         ##
glm_meta<-read.table(paste(glm_dir,"/glioma_meta.txt",sep=""),sep="\t",header = T,row.names = "Cell_name")              ##
glm<-CreateSeuratObject(counts = glm_data,min.cells = 5,min.features = 200,meta.data =glm_meta,project = "GSE84465")    ##
glm@meta.data$study<-"gse84465"                                                                                         ##
glm@meta.data$sample<-glm$study                                                                                         ##
glm2_dir<-"/export/home/lileijie/pan_cancer/other_tumor/glioma/glioma_GSE102130"                                        ##
glm2_data<-read.table(paste(glm2_dir,"/GSE102130_glioma.txt",sep = ""),sep="\t",header = T,row.names = "Gene")          ##
glm2_meta<-read.table(paste(glm2_dir,"/GSE102130_meta.txt",sep=""),sep="\t",header = T,row.names = "Cell_name")         ##
glm2<-CreateSeuratObject(counts = glm2_data,min.cells = 5,min.features = 200,meta.data =glm2_meta,project = "GSE102130")##
glm2@meta.data$study<-"gse102130"                                                                                       ##
glm2.namelist<-names(glm2$study)                                                                                        ##
glm2.samplelist<-glm2.namelist                                                                                          ##
for (i in 1:length(glm2.namelist)) {                                                                                    ##
  glm2.samplelist[i]<-strsplit(glm2.namelist[i],"_")[[1]][1]                                                            ##
  glm2.samplelist[i]<-strsplit(glm2.samplelist[i],"\\.")[[1]][1]                                                        ##
}                                                                                                                       ##
glm2.samplelist<-plyr::mapvalues(x = glm2.samplelist, from = "Oligo",to = "MUV17")                                      ##
names(glm2.samplelist)<-names(glm2$study)                                                                               ##
glm2@meta.data$sample<-glm2.samplelist                                                                                  ##
glm_all<-merge(x=glm,y = glm2)                                                                                          ##
##########################################################################################################################
########## colorectal cancer #############################################################################################
crc_dir<-"/export/home/lileijie/pan_cancer/other_tumor/colorectalcancer"                                                ##
crc_data<-read.table(paste(crc_dir,"/GSE81861_CRC.txt",sep = ""),sep="\t",header = T)                                   ##
crc_data<-as.matrix(crc_data)                                                                                           ##
crc_name.list<-crc_data[duplicated(crc_data[,1]),1]                                                                     ##
for (i in 1:length(crc_name.list)) {                                                                                    ##
  index<-crc_data[,1]==crc_name.list[i]                                                                                 ##
  crc_data[index[i],2:ncol(crc_data)]<-colSums(apply(crc_data[index,2:ncol(crc_data)],2,as.numeric))                    ##
  print(i)                                                                                                              ##
}                                                                                                                       ##
crc_data<-as.data.frame(crc_data)                                                                                       ##
crc_data<-crc_data[!duplicated(crc_data$Gene_name),]                                                                    ##
rownames(crc_data)<-crc_data$Gene_name                                                                                  ##
crc_data<-crc_data[,-1]                                                                                                 ##
crc_meta<-read.table(paste(crc_dir,"/CRC_meta.txt",sep=""),sep="\t",header = T,row.names = "Cell_name")                 ##
crc<-CreateSeuratObject(counts = crc_data,min.cells = 5,min.features = 200,meta.data =crc_meta,project = "GSE81861")    ##
crc@meta.data$study<-"gse81861"                                                                                         ##
crc@meta.data$sample<-crc$study                                                                                         ##
##########################################################################################################################
## merge all ## remove batcheffect all only once #########################################################################
ostc_all@meta.data$cancertype<-"OSTC"                                                                                   ##
bc_all@meta.data$cancertype<-"BC"                                                                                       ##
mela1@meta.data$cancertype<-"MC"                                                                                        ##
ovc@meta.data$cancertype<-"OVC"                                                                                         ##
scc@meta.data$cancertype<-"SCC"                                                                                         ##
glm_all@meta.data$cancertype<-"GLMC"                                                                                    ##
crc@meta.data$cancertype<-"CRC"                                                                                         ##
#othercancer_all<-merge(x=ostc_all,y=c(bc_all,mela1,ovc,scc,glm_all,crc))                                               ##
#othercancer_all.list <- SplitObject(othercancer_all, split.by = "cancertype")# same with list                          ##
ostc_all.list<-SplitObject(ostc_all,split.by="ident")                                                                   ##
othercancer_all.list<-c(ostc_all.list,list(BC=bc_all,OVC=ovc,SCC=scc,GLMC=glm_all,MC=mela1,CRC=crc))                    ##
rm(ostc_all,bc_all,mela1,ovc,scc,glm_all,crc,ostc,ostc1,ostc2,ostc3,ostc4,ostc5,ostc6,ostc7,ostc8,ostc9,ostc10,a,glm,   ##
   glm2,glm2_data,ostc11,bc_data1,bc_data2,bc1,bc2,bc2_data,mela1_data,scc_data,glm,glm_data,crc_data)                  ##
for (i in 1:length(othercancer_all.list)) {                                                                             ##
  othercancer_all.list[[i]] <- NormalizeData(othercancer_all.list[[i]], verbose = F,normalization.method = "LogNormalize")
  othercancer_all.list[[i]]<-FindVariableFeatures(object=othercancer_all.list[[i]],                                     ##
                                                  selection.method = "vst",nfeatures = 2000)                            ##
}                                                                                                                       ##
othercancer_all.anchors <- FindIntegrationAnchors(object.list = othercancer_all.list, dims = 1:40,                      ##
                                                  k.anchor = 5,k.filter = 20)                                           ##
othercancer_all <- IntegrateData(anchorset = othercancer_all.anchors, dims = 1:40) 
save.image(file="othercancer_all.RData")
# seperate into two part
othercancer_all.list<-list(OSTC=ostc_all) #11w                                                                          ##
othercancer_all2.list<-list(BC=bc_all,OVC=ovc,SCC=scc,GLMC=glm_all,MC=mela1,CRC=crc) #10w                               ##
rm(ostc_all,bc_all,mela1,ovc,scc,glm_all,crc,ostc,ostc1,ostc2,ostc3,ostc4,ostc5,ostc6,ostc7,ostc8,ostc9,ostc10,a,glm,   ##
   glm2,glm2_data,ostc11,bc_data1,bc_data2,bc1,bc2,bc2_data,mela1_data,scc_data,glm,glm_data,crc_data)                  ##
for (i in 1:length(othercancer_all.list)) {                                                                             ##
  othercancer_all.list[[i]] <- NormalizeData(othercancer_all.list[[i]], verbose = F,normalization.method = "LogNormalize")
  othercancer_all.list[[i]]<-FindVariableFeatures(object=othercancer_all.list[[i]],                                     ##
                                                  selection.method = "vst",nfeatures = 2000)                            ##
}                                                                                                                       ##
othercancer_all.anchors <- FindIntegrationAnchors(object.list = othercancer_all.list, dims = 1:40,                      ##
                                                  k.anchor = 5,k.filter = 20)                                           ##
othercancer_all <- IntegrateData(anchorset = othercancer_all.anchors, dims = 1:40)                                      ##
othercancer_all <- ScaleData(othercancer_all)                                                                           ##
othercancer_all <- RunPCA(object = othercancer_all,npcs=100)                                                            ##
pdf(file = "othercancer_all_pca_use.pdf")                                                                               ##
ElbowPlot(othercancer_all, ndims = 100)                                                                                 ##
dev.off()                                                                                                               ##
othercancer_all <- JackStraw(object = othercancer_all,dims=100, num.replicate = 100)                                    ##
othercancer_all <- ScoreJackStraw(object = othercancer_all, dims = 1:100)                                               ##
figure_name8<-paste("othercancer_all_jackstraw",".pdf",sep = "")                                                        ##
pdf(file = figure_name8,width = 20,height = 10)                                                                         ##
JackStrawPlot(object = othercancer_all, dims = 1:100)                                                                   ##
dev.off()                                                                                                               ##
### othercancer_all2                                                                                                    ##
for (i in 1:length(othercancer_all2.list)) {                                                                            ##
  othercancer_all2.list[[i]] <- NormalizeData(othercancer_all2.list[[i]], verbose = F,normalization.method = "LogNormalize")
  othercancer_all2.list[[i]]<-FindVariableFeatures(object=othercancer_all2.list[[i]],                                   ##
                                                   selection.method = "vst",nfeatures = 2000)                           ##
}                                                                                                                       ##
othercancer_all2.anchors <- FindIntegrationAnchors(object.list = othercancer_all2.list, dims = 1:40,                    ##
                                                   k.anchor = 5,k.filter = 20)                                          ##
othercancer_all2 <- IntegrateData(anchorset = othercancer_all2.anchors, dims = 1:40)                                    ##
othercancer_all2 <- ScaleData(othercancer_all2)                                                                         ##
othercancer_all2 <- RunPCA(object = othercancer_all2,npcs=100)                                                          ##
pdf(file = "othercancer_all_pca_use.pdf")                                                                               ##
ElbowPlot(othercancer_all2, ndims = 100)                                                                                ##
dev.off()                                                                                                               ##
save.image(file="othercancer_all.RData")                                                                                ##
############### pca ######################################################################################################
pcause=23                                                                                                               ##
orig.ident<-othercancer_all@active.ident                                                                                ##
sample.orig.ident<-orig.ident                                                                                           ##
othercancer_all <- FindNeighbors(object = othercancer_all, dims = 1:pcause)                                             ##
othercancer_all <- FindClusters(object = othercancer_all, resolution = 0.5)                                             ##
othercancer_all <- RunTSNE(object = othercancer_all, dims = 1:pcause)                                                   ##
pdf(file = paste("othercancer_all_tsne_cluster",pcause,".pdf",sep = ""),width = 10,height = 8)                          ## 
TSNEPlot(object = othercancer_all,label = T)                                                                            ##
dev.off()                                                                                                               ##
othercancer_all23_backup<-othercancer_all                                                                               ##
#othercancer_all@active.ident<-as.factor(othercancer_all$cancertype) #这里测试一下                                      ##
pdf(file = "othercancer_all_sample23.pdf",width = 10,height = 8)                                                        ##
DimPlot(object = othercancer_all,reduction = "tsne",group.by = "cancertype")                                            ##
dev.off()                                                                                                               ##
save.image(file="othercancer_all_final.RData")                                                                          ##
##########################################################################################################################
############## calculate marker ##########################################################################################
othercancer_cluster.ident<-othercancer_all@active.ident                                                                 ##
othercancer_all.markers <- FindAllMarkers(object = othercancer_all, only.pos = TRUE)                                    ##
othercancer_all.markers %>% group_by(cluster) %>% top_n(10, avg_logFC) -> top10                                         ##
othercancer_all.markers %>% group_by(cluster) %>% top_n(30, avg_logFC) -> top30                                         ##
top10<-top10[order(as.numeric(as.character(top10$cluster))),]                                                           ##
top30<-top30[order(as.numeric(as.character(top30$cluster))),]                                                           ##
pdf(file = "othercancer_all_clustermaker_heatmap.pdf",width = 14,height = 12)                                           ##
DoHeatmap(object = othercancer_all, features = top10$gene,label = TRUE,group.bar= T)                                    ##
dev.off()                                                                                                               ##
##########################################################################################################################
################################## cellmarker annotation #################################################################
gene2cell<-read.csv("/export/home/lileijie/singlecell/pan_cancer/all_cell_marker_onebyone_withrepeat.csv")              ##
gene2cell$geneSymbol<-as.matrix(gene2cell$geneSymbol)                                                                   ##
gene2cell$geneSymbol[is.na(gene2cell$geneSymbol)]<-"NA"                                                                 ##
top30$cellmarker_celltype<-"unknown"                                                                                    ##
for (i in 1:nrow(top30)) {                                                                                              ##
  sign<-gene2cell$cellName[gene2cell$geneSymbol==as.character(top30$gene[i])]                                           ##
  if (length(sign)){                                                                                                    ##
    sign2<-as.character(sign)                                                                                           ##
    sign3<-paste(sign2,collapse=";")                                                                                    ##
    top30$cellmarker_celltype[i]<-sign3                                                                                 ##
  }                                                                                                                     ##
}                                                                                                                       ##
write.csv(top30,"othercancer_all_clusters_cellmarkercelltype.csv")                                                      ##
##########################################################################################################################
################################ cellmarker figure #######################################################################
# extract CXCR4 data                                                                                                    ##
occellmarker_figure<-othercancer_all@active.ident                                                                       ##
index<-which(rownames(othercancer_all@assays$integrated)=="CXCR4")                                                      ##
occellmarker_figure<-cbind(occellmarker_figure,t(as.matrix(othercancer_all@assays$integrated[index,])))                 ##
index<-which(rownames(othercancer_all@assays$RNA)=="CXCR4")                                                             ##
occellmarker_figure<-cbind(occellmarker_figure,t(as.matrix(othercancer_all@assays$RNA[index,])))                        ##
colnames(occellmarker_figure)<-c("Cluster","CXCR4_integrated","CXCR4")                                                  ##
occellmarker_figure<-as.data.frame(occellmarker_figure)                                                                 ##
occellmarker_figure$Cluster<-as.factor(occellmarker_figure$Cluster-1)                                                   ##
occellmarker_figure$celltype<-"Other Cells"                                                                             ##
occellmarker_figure$celltype[occellmarker_figure$Cluster==4]<-"CSC"                                                     ##
occellmarker_figure$celltype[occellmarker_figure$Cluster==7]<-"CSC"                                                     ##
##ggplot2                                                                                                               ##
pdf(file="violin_test2.pdf",width = 5,height = 8)                                                                       ##
p<-ggplot(occellmarker_figure,aes(celltype,CXCR4_integrated),) + geom_boxplot()                                         ##
p<-p+theme_bw()+theme(panel.border = element_blank(),axis.line = element_line(colour = "black",size = 1))               ##
p<-p+theme(text = element_text(size = 24))                                                                              ##
p<-p+theme(panel.grid.major.y = element_blank(),                                                                        ##
           panel.grid.minor.y = element_blank(),                                                                        ##
           panel.grid.major.x = element_blank(),                                                                        ##
           panel.grid.minor.x = element_blank())                                                                        ##
dev.off()                                                                                                               ##
marker_show="CXCR4"                                                                                                     ##
p<-FeaturePlot(object = othercancer_all,features = marker_show,cols = c("grey","#d9a396", "red"), reduction = "tsne")   ##
p$data[,4]<-as.numeric(othercancer_all@assays$RNA[rownames(othercancer_all@assays$RNA)==marker_show,])                  ##
pdf(file = "othercancer_all_tsne_focusgenes.pdf",width = 8,height = 8)                                                  ##
print(p)                                                                                                                ##
dev.off()                                                                                                               ##
##########################################################################################################################
########################### only judge csc ###############################################################################
othercsc_cluster<-c(4,7)
ocsc<-subset(x=othercancer_all,idents=c(4,7))
save(ocsc, file = "other_csc47.RData")