############################First Time run###############################
install.packages("ggplot2")                                            ##
install.packages("pheatmap")                                           ##
install.packages("plyr")                                               ##
if (!requireNamespace("BiocManager", quietly = TRUE))                  ##
  install.packages("BiocManager")                                      ##
BiocManager::install("AnnotationHub")                                  ##
BiocManager::install("org.Bt.eg.db")                                   ##
BiocManager::install("clusterProfiler")                                ##
#########################################################################
rm(list = ls())
library(ggplot2)
library(pheatmap)
library(AnnotationHub)
library(org.Bt.eg.db)
library(clusterProfiler)
library(plyr)
setwd("D:\\GO")
gene_list<-read.table("gene_list.txt",sep = "\t",header = T)
gene_list<-read.table("p0.05 FDC-2-2gene_list_1.txt",sep = "\t",header = T)
gene_list$state<-NA
gene_list$state[gene_list$Fold.change>0]="Up"
gene_list$state[gene_list$Fold.change<0]="Down"
############################### up gene ########################################
setwd("2.20/")
diff_gene_p_up<-gene_list[gene_list$state=="Up",]
f<-as.data.frame(diff_gene_p_up)
EG2symbol=toTable(org.Bt.egSYMBOL)
fid=as.character(f$Gene.symbol)
geneLists=data.frame(symbol=fid)
results_up=merge(geneLists,EG2symbol,by='symbol',all.x=T)
id_up=na.omit(results_up$gene_id)
id_back<-id
ego_up <- enrichGO(OrgDb="org.Bt.eg.db", gene = id_up, ont = "ALL", pvalueCutoff = 0.05,readable = T,minGSSize = 1)
write.csv(ego_up@result,"diff_up_go.csv")
#down GO
diff_gene_p_Down<-gene_list[gene_list$state=="Down",]
f<-as.data.frame(diff_gene_p_Down)
fid=as.character(f$Gene.symbol)
geneLists=data.frame(symbol=fid)
results_down=merge(geneLists,EG2symbol,by='symbol',all.x=T)
id_down=na.omit(results_down$gene_id)
ego_down <- enrichGO(OrgDb="org.Bt.eg.db", gene = id_down, ont = "ALL", pvalueCutoff = 0.05,readable= TRUE,minGSSize = 1)
write.csv(cbind(id_up,id_down),"gene_id_list.csv")
if (nrow(ego_down@result)>15) {
  ego_all<-ego_down@result[1:15,c(3,10)]
}else if (nrow(ego_down@result)<15 & nrow(ego_down@result)>0) {
  ego_all<-ego_down@result[,c(3,10)]
}else{
  ego_down <- enrichGO(OrgDb="org.Hs.eg.db", gene = id, ont = "ALL", pvalueCutoff = 0.1, minGSSize = 1,readable= TRUE)
  if (isEmpty(ego_down)){
    print("There are few down regulated genes!")
  }else{
    if (nrow(ego_down@result)>10) {
      ego_all<-ego_down@result[1:10,c(3,10)]
    }else if (nrow(ego_down@result)<10 & nrow(ego_down@result)>0) {
      ego_all<-ego_down@result[,c(3,10)]
    }
  }
}
if (!isEmpty(ego_down@result)){
  write.csv(ego_down@result,"diff_all_down_go.csv")
  ##merge
  ego_all$Count<--ego_all$Count
  if (nrow(ego_up@result)>15) {
    ego_all<-rbind(ego_all,ego_up@result[1:15,c(3,10)])
  }else if (nrow(ego_up@result)<15 & nrow(ego_up@result>0)) {
    ego_all<-rbind(ego_all,ego_up@result[,c(3,10)])
  }
  a<-min(ego_all$Count)
  b<-max(ego_all$Count)
  p<-ggplot(ego_all,aes(x=reorder(Description,Count),y=Count,fill=Count))+
    geom_bar(stat = "identity",colour="NA",width = 0.9,position = position_dodge(0.7))
  p<-p+xlab("")+scale_y_continuous(breaks = round(seq(a,b,(b-a)/6)),name = "Gene Count")+coord_flip()
  p<-p+theme_bw()+theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank())
  p<-p+scale_fill_gradient2(low="#36648B",high="red",mid="white",midpoint = 0,name="Genes")
  p<-p+theme(text=element_text(size=16,  family="serif"))+labs(title = " Gene Ontology Analysis")
  ggsave(p,filename = "GO_bar.jpeg",height = 10,width = 12)
}else{
  if (nrow(ego_up@result)>15) {
    ego_all<-ego_up@result[1:15,c(3,10)]
  }else if (nrow(ego_up@result)<15 & nrow(ego_up@result>0)) {
    ego_all<-ego_up@result[,c(3,10)]
  }
  a<-min(ego_all$Count)
  b<-max(ego_all$Count)
  p<-ggplot(ego_all,aes(x=reorder(Description,Count),y=Count,fill=Count))+
    geom_bar(stat = "identity",colour="NA",width = 0.9,position = position_dodge(0.7))
  p<-p+xlab("")+scale_y_continuous(breaks = round(seq(a,b,(b-a)/6)),name = "Gene Count")+coord_flip()
  p<-p+theme_bw()+theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank())
  p<-p+scale_fill_gradient2(low="#36648B",high="red",mid="white",midpoint = 0,name="Genes")
  p<-p+theme(text=element_text(size=16,  family="serif"))+labs(title = " Gene Ontology Analysis")
  ggsave(p,filename = "GO_bar.jpeg",height = 10,width = 12)
}
