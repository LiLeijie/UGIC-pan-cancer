library(Seurat)
library(dplyr)
library(Matrix)
#library(DDRTree)
library(pheatmap)
library(plyr)
library(data.table)
library(ggplot2)
library(AnnotationHub)
library(org.Hs.eg.db)
library(clusterProfiler)
setwd("/export/home/lileijie/pan_cancer/escc/data")
#load data one by one
##################################EAC & ESCC########################################################################################
exp<-read.table("./SRR613/all_cell_exp.txt",header = T,row.names = "Geneid")                                                      ##
meta<-read.table("./SRR613/meta.txt",sep="\t",header = T,row.names = "Cell_name")                                                 ##
so_srr613<-CreateSeuratObject(counts = exp,min.cells = 5,min.features = 200,meta.data =meta,project = "srr613")                   ##
#????ID                                                                                                                           ##
now<-c("EA02-C2","EA01-Cancer","EA02-C1","ESC01-Cancer","ESC03-C2","ESC03-C1","ESC02-Cancer")                                     ##
new<-c('EAC02','EAC01',"EAC02","ESC01","ESC03","ESC03","ESC02")                                                                   ##
so_srr613$Tissue<-plyr::mapvalues(x=so_srr613$Tissue, from=now, to=new)                                                           ##
so_srr613@meta.data$study<-as.matrix(so_srr613$Tissue)                                                                            ##
so_srr613@active.ident<-so_srr613$Tissue                                                                                          ##
##################################HNSCC ############################################################################################
#GSE103322                                                                                                                        ##
exp2<-read.table("./GSE103322/HNSCC_all_data.txt",sep="\t",header = T,row.names = "gene_id")                                      ##
exp2<-exp2[-c(1:5),]#rm other information                                                                                         ##
meta2<-read.table("./GSE103322/meta.txt",sep="\t",header = T,row.names = "Cell_name")                                             ##
so_gse103<-CreateSeuratObject(counts = exp2,min.cells = 5,min.features = 200,meta.data =meta2,project = "gse103322")              ##
so_gse103@meta.data$study<-"gse103"                                                                                               ##
so_gse103.sample<-so_gse103@active.ident                                                                                          ##
now<-c("HN23","HN28","HN26","HN25","HNSCC")                                                                                       ##
new<-c("HNSCC23","HNSCC28","HNSCC26","HNSCC25","HNSCC9")                                                                          ##
sample.orig.ident<-plyr::mapvalues(x = so_gse103.sample, from = now, to = new)                                                    ##
so_gse103@active.ident<-sample.orig.ident                                                                                         ##
so_gse103@meta.data$study<-as.matrix(sample.orig.ident)                                                                           ##
so_gse103.list <- SplitObject(so_gse103, split.by = "study")                                                                      ##
for (i in 1:length(x = so_gse103.list)) {                                                                                         ##
  so_gse103.list[[i]] <- NormalizeData(object = so_gse103.list[[i]], verbose = FALSE)                                             ##
  so_gse103.list[[i]] <- FindVariableFeatures(object = so_gse103.list[[i]], selection.method = "vst",  nfeatures = 2000,          ##
                                              verbose = FALSE)                                                                    ##
}                                                                                                                                 ##
use.list<-0                                                                                                                       ##
for (i in 1:length(so_gse103.list)) {                                                                                             ##
  if(length(so_gse103.list[[i]]@active.ident)>60){                                                                                ##
    use.list<-c(use.list,names(so_gse103.list[i]))                                                                                ##
  }                                                                                                                               ##
}                                                                                                                                 ##
use.list<-use.list[-1]                                                                                                            ##
so_gse10360<-subset(x=so_gse103,subset = orig.ident%in%use.list)                                                                  ##
#so_gse103.list100<-so_gse103.list[use.list]                                                                                      ##
##################################GC ###############################################################################################
exp3<-read.table("./GC/GSE134520_IGC6/dt.EGC.txt",sep="\t",header = T,row.names = "Geneid")                                       ##
meta3<-read.table("./GC/GSE134520_IGC6/dt.EGC.meta.txt",sep="\t",header = T,row.names = "Cell_name")                              ##
so_gse134<-CreateSeuratObject(counts = exp3,                                                                                      ##
                              min.cells = 5,                                                                                      ##
                              min.features = 200,                                                                                 ##
                              meta.data =meta3,                                                                                   ##
                              project = "gse134520")                                                                              ##
so_gse134@meta.data$study<-"EGC" #gse134??IGC6                                                                                    ##
so_gse134[["percent.mt"]] <- PercentageFeatureSet(object = so_gse134, pattern = "^MT-")                                           ##
so_gse134 <- NormalizeData(object = so_gse134, normalization.method = "LogNormalize", scale.factor = 10000)                       ##
so_gse134 <- FindVariableFeatures(object = so_gse134, selection.method = "vst", nfeatures = 2000)                                 ##
all.genes <- rownames(x = so_gse134)                                                                                              ##
so_gse134 <- ScaleData(object = so_gse134, features=all.genes)                                                                    ##
so_gse134@active.ident<-so_gse134$orig.ident                                                                                      ##
list_GC<-c("DGC/","IGC1/","IGC2/","IGC3","IGC4","IGC5","MGC1","MGC2","MGC3")                                                      ##
for (i in 1:length(list_GC)) {                                                                                                    ##
  data <- eval(parse(text = paste("Read10X(data.dir = './GC/",list_GC[i],"')",sep = "")))                                         ##
  sign<-strsplit(list_GC[i],"/")                                                                                                  ##
  name<-sign[[1]][1]                                                                                                              ##
  gall <- CreateSeuratObject(counts = data, min.cells = 3, min.features = 200, project = name)                                    ##
  gall@meta.data$tech<-paste("HRA051_",name,sep = "")                                                                             ##
  ###qc###                                                                                                                        ##    
  gall[["percent.mt"]] <- PercentageFeatureSet(object = gall, pattern = "^MT-")                                                   ##
  pdf(file = paste(name,".pdf",sep = ""))                                                                                         ##
  print(VlnPlot(object = gall, features = c("nFeature_RNA","nCount_RNA","percent.mt"),ncol=3))                                    ##
  dev.off()                                                                                                                       ##
  gall <- subset(x = gall, subset = nFeature_RNA > 200 & nFeature_RNA < 6000 & percent.mt < 15)                                   ##
  gall_lowmito <- NormalizeData(object = gall, normalization.method = "LogNormalize", scale.factor = 10000)                       ##
  gall_lowmito <- FindVariableFeatures(object = gall_lowmito, selection.method = "vst", nfeatures = 2000)                         ##
  all.genes <- rownames(x = gall_lowmito)                                                                                         ##
  gall_lowmito <- ScaleData(object = gall_lowmito, features=all.genes)                                                            ##
  ##merge                                                                                                                         ##
  eval(parse(text = paste("gc",i,"<-gall_lowmito",sep = "")))                                                                     ##
  if (i==1) {                                                                                                                     ##
    name_list<-name                                                                                                               ##
  }else{                                                                                                                          ##
    name_list<-c(name_list,name)                                                                                                  ##
  }                                                                                                                               ##
}                                                                                                                                 ##
gc_all<-merge(x=gc1,y=c(gc2,gc3,gc4,gc5,gc6,gc7,gc8,gc9,so_gse134),add.cell.ids=c(name_list,"EGC"))                               ##
gc_all_sample.id<-gc_all@active.ident                                                                                             ##
gc_all_sample.id<-plyr::mapvalues(x=gc_all_sample.id,from = "gse134520",to="EGC")                                                 ##
gc_all@active.ident<-gc_all_sample.id                                                                                             ##
gc_all@meta.data$study<-as.matrix(gc_all_sample.id)                                                                               ##
####################################################################################################################################
setwd("./re")
##################################remove batch effect ##############################################################################
pancancer_all<-merge(x = so_gse10360,y = c(so_srr613,gc_all))                                                                     ##
pancancer_all.list <- SplitObject(pancancer_all, split.by = "study")                                                              ##
for (i in 1:length(x = pancancer_all.list)) {                                                                                     ##
  pancancer_all.list[[i]] <- NormalizeData(object = pancancer_all.list[[i]], verbose = FALSE)                                     ##
  pancancer_all.list[[i]] <- FindVariableFeatures(object = pancancer_all.list[[i]],                                               ##
                                                  selection.method = "vst",  nfeatures = 2000, verbose = FALSE)                   ##
}                                                                                                                               ##
pancancer_all.anchors <- FindIntegrationAnchors(object.list = pancancer_all.list, dims = 1:40,                                    ##
                                                k.anchor = 5,k.filter = 20)#approx????????????                                    ##
pancancer_all <- IntegrateData(anchorset = pancancer_all.anchors, dims = 1:50)                                                    ##
pancancer_all <- ScaleData(pancancer_all, features = all.genes)                                                                   ##
pancancer_all <- RunPCA(object = pancancer_all,npcs=80)                                                                           ##
pdf(file = "pancancer_all_pca_use.pdf")                                                                                           ##
ElbowPlot(pancancer_all, ndims = 80)                                                                                              ##
dev.off()                                                                                                                         ##
pancancer_all <- JackStraw(object = pancancer_all,dims=80, num.replicate = 80)                                                    ##
pancancer_all <- ScoreJackStraw(object = pancancer_all, dims = 1:80)                                                              ##
figure_name8<-paste("pancancer_all_jackstraw",".pdf",sep = "")                                                                    ##
pdf(file = figure_name8,width = 20,height = 10)                                                                                   ##
JackStrawPlot(object = pancancer_all, dims = 1:80)                                                                                ##
dev.off()                                                                                                                         ##
####################################################################################################################################
############################################ tsne ##################################################################################
pcause=80                                                                                                                         ##
orig.ident<-pancancer_all@active.ident                                                                                            ##
sample.orig.ident<-orig.ident                                                                                                     ##
#save.SNN = T saves the SNN so that the clustering algorithm can be rerun using the same graph but with a different resolution    ##
pancancer_all <- FindNeighbors(object = pancancer_all, dims = 1:pcause)                                                           ##
pancancer_all <- FindClusters(object = pancancer_all, resolution = 0.5)                                                           ##
pancancer_all <- RunTSNE(object = pancancer_all, dims = 1:pcause)                                                                 ##
pdf(file = paste("pancancer_all_tsne_cluster2",pcause,".pdf",sep = ""),width = 8,height = 6)                                      ##
TSNEPlot(object = pancancer_all,label = T,pt.size = 1.5)                                                                          ##
dev.off()                                                                                                                         ##
pancancer_all_backup<-pancancer_all#????                                                                                          ##
cluster.ident<-pancancer_all@active.ident                                                                                         ##
pancancer_all@active.ident<-sample.orig.ident                                                                                     ##
figure_name10<-paste("pancancer_all_tsne_sample2",".pdf",sep = "")                                                                ##
pdf(file = figure_name10,width = 12,height = 8)                                                                                   ##
DimPlot(object = pancancer_all,reduction = "tsne",group.by = "ident",pt.size = 1.3)                                               ##
dev.off()                                                                                                                         ##
#order                                                                                                                            ##
now<-c("IGC1","IGC2","IGC3","IGC4","IGC5","MGC1","MGC2","MGC3","EAC01","EAC02","ESC01","ESC02","ESC03","HNSCC10","HNSCC12",       ##
       "HNSCC13","HNSCC16","HNSCC17","HNSCC18","HNSCC20","HNSCC22","HNSCC24","HNSCC25","HNSCC26","HNSCC28","HNSCC5","HNSCC6","HNSCC8")#
new<-c(rep("IGC",5),rep("MGC",3),rep("EAC",2),rep("ESC",3),rep("HNSCC",15))                                                       ##
type.orig.ident<-plyr::mapvalues(x = sample.orig.ident, from = now, to = new)                                                     ##
pancancer_all@active.ident<-type.orig.ident                                                                                       ##
#sort=c("EAC01","EAC02","ESC01","ESC02","ESC03","GC","HNSCC5","HNSCC6","HNSCC7","HNSCC8","HNSCC9",                                ##
#       "HNSCC10","HNSCC12","HNSCC13","HNSCC16","HNSCC17","HNSCC18","HNSCC20","HNSCC22","HNSCC23",                                ##
#       "HNSCC24","HNSCC25","HNSCC26","HNSCC28")                                                                                  ##
#sort<-rev(sort)                                                                                                                  ##
pdf(file = "pancancer_all_tsne_type2.pdf",width = 10,height = 8)                                                                  ##
DimPlot(object = pancancer_all,reduction = "tsne",group.by = "ident",pt.size = 1.5) #order = sort????                             ##
dev.off()                                                                                                                         ##
now<-levels(type.orig.ident)                                                                                                      ##
new<-c("GC","EC","EC","HNSCC","GC","GC")                                                                                          ##
type.orig.ident2<-plyr::mapvalues(x=type.orig.ident,from=now,to=new)                                                              ##
pancancer_all@meta.data$cancertype2<-type.orig.ident2                                                                             ##
pdf(file = "pancancer_all_tsne_cancertype3.pdf",width = 10,height = 8)                                                            ##
DimPlot(object = pancancer_all,reduction = "tsne",group.by = "cancertype2",pt.size = 1.5)                                         ##
dev.off()                                                                                                                         ##
####################################################################################################################################
###################################  cluster marker ################################################################################
pancancer_all@active.ident<-cluster.ident                                                                                         ##
pancancer_all.markers <- FindAllMarkers(object = pancancer_all, only.pos = TRUE)                                                  ##
pancancer_all.markers %>% group_by(cluster) %>% top_n(10, avg_logFC) -> top10                                                     ##
pancancer_all.markers %>% group_by(cluster) %>% top_n(30, avg_logFC) -> top30                                                     ##
top10<-top10[order(as.numeric(as.character(top10$cluster))),]                                                                     ##
top30<-top30[order(as.numeric(as.character(top30$cluster))),]                                                                     ##
pdf(file = "pancancer_all_clustermaker_heatmap.pdf",width = 14,height = 12)                                                       ##
DoHeatmap(object = pancancer_all, features = top10$gene,label = TRUE,group.bar= T)                                                ##
dev.off()                                                                                                                         ##
####################################################################################################################################
#################################### marker to celltype  article ###################################################################
gene2cell<-read.table("/export/home/lileijie/pan_cancer/GCcellmarker2celltype.txt",sep="\t",header=T)                             ##
top30$celltype<-"unknown"                                                                                                         ##
for (i in 1:nrow(top30)) {                                                                                                        ##
  sign<-gene2cell$celltype[gene2cell$cellmarker==as.character(top30$gene[i])]                                                     ##
  if (length(sign)){                                                                                                              ##
    print(i)                                                                                                                      ##
    sign2<-as.character(sign)                                                                                                     ##
    sign3<-paste(sign2,collapse=";")                                                                                              ##
    top30$celltype[i]<-sign3                                                                                                      ##
  }                                                                                                                               ##
}                                                                                                                                 ##
write.csv(top30,"pancancer_all_clusters_makersGC.csv")                                                                            ##
####################################################################################################################################
################################## cellmarker annotation ###########################################################################
gene2cell<-read.csv("/export/home/lileijie/singlecell/pan_cancer/all_cell_marker_onebyone_withrepeat.csv")                        ##
gene2cell$geneSymbol<-as.matrix(gene2cell$geneSymbol)                                                                             ##
gene2cell$geneSymbol[is.na(gene2cell$geneSymbol)]<-"NA"                                                                           ##
top30$cellmarker_celltype<-"unknown"                                                                                              ##
for (i in 1:nrow(top30)) {                                                                                                        ##
  sign<-gene2cell$cellName[gene2cell$geneSymbol==as.character(top30$gene[i])]                                                     ##
  if (length(sign)){                                                                                                              ##
    print(i)                                                                                                                      ##
    sign2<-as.character(sign)                                                                                                     ##
    sign3<-paste(sign2,collapse=";")                                                                                              ##
    top30$cellmarker_celltype[i]<-sign3                                                                                           ##
  }                                                                                                                               ##
}                                                                                                                                 ##
write.csv(top30,"pancancer_all_clusters_cellmarkercelltype.csv")                                                                  ##
####################################################################################################################################
#################################### celltype name #################################################################################
#readRDS("pancancer_all.rds")                                                                                                     ##
cluster.ident<-pancancer_all@active.ident                                                                                         ##
cellcluster<-read.table("/export/home/lileijie/pan_cancer/escc/data/GC_cellname_manual.txt",sep="\t",header = T)                  ##
current.cluster.ids <- cellcluster$cluster                                                                                        ##
new.cluster.ids <- as.character(cellcluster$celltype)                                                                             ##
celltype.ident <- plyr::mapvalues(x = cluster.ident, from = current.cluster.ids,to = new.cluster.ids)                             ##
pancancer_all@active.ident<-celltype.ident                                                                                        ##
pancancer_all@meta.data$celltype<-as.matrix(celltype.ident)                                                                       ##
pancancer_all@meta.data$cancertype<-as.matrix(type.orig.ident)                                                                    ##
pancancer_all@meta.data$sampletype<-as.matrix(sample.orig.ident)                                                                  ##
pancancer_all<-subset(x=pancancer_all,idents=c("T cell","Epithelial cell","B cell","Nature killer cell",                          ##  
                                               "Fibroblast","Plasma cell","Cancer Stem cell","Mast cells","Endothelial cell"))   ##
type.orig.ident<-as.factor(pancancer_all@meta.data$cancertype)                                                                    ##
celltype.ident<-as.factor(pancancer_all@meta.data$celltype)                                                                       ##
pdf(file = paste("pancancer_all_tsne_cellname_manual2",".pdf",sep = ""),width = 8,height = 6)                                     ##
TSNEPlot(object = pancancer_all, label = TRUE, pt.size = 1.3,label.size = 3)                                                      ##
dev.off()                                                                                                                         ##
####################################################################################################################################
################################# celltype marker heatmap ##########################################################################
pancancer_all.celltype_markers <- FindAllMarkers(object = pancancer_all, only.pos = TRUE)                                         ##
pancancer_all.celltype_markers %>% group_by(cluster) %>% top_n(10, avg_logFC) -> top10                                            ##
pancancer_all.celltype_markers %>% group_by(cluster) %>% top_n(5, avg_logFC) -> top5                                              ##
pdf(file = "pancancer_all_celltypemaker_heatmap.pdf",width = 14,height = 12)                                                      ##
DoHeatmap(object = pancancer_all, features = top10$gene, label = TRUE,group.bar= T)+                                              ##
  scale_fill_gradientn(colors = c("white","white","steelblue"))                                                           ##
dev.off()                                                                                                                         ##
####################################################################################################################################
####################################### marker map tsne ############################################################################
marker_show=c("CD3D","KRT8","MS4A1","CCL3","PDGFRA","IGHG3","EPCAM","TPSB2","ECSCR")                                              ##
p<-FeaturePlot(object = pancancer_all,features = marker_show,cols = c("grey", "red"), reduction = "tsne",ncol = 4)                ##
for (i in 1:length(marker_show)) {                                                                                                ##
  p[[i]]$data[,4]<-as.numeric(pancancer_all@assays$RNA[rownames(pancancer_all@assays$RNA)==marker_show[i],])                      ##
}                                                                                                                                 ##
#save                                                                                                                             ##
pdf(file = paste("pancancer_all_tsne_focusgenes2",".pdf",sep = ""),width = 14,height = 10)                                        ##
print(p)                                                                                                                          ##
dev.off()                                                                                                                         ##
####################################################################################################################################
##################################### self violin function #########################################################################
## violin main function                                                                                                           ##
modify_vlnplot <- function(obj, feature, pt.size = 0, plot.margin = unit(c(-0.75, 0, -0.75, 0), "cm"),...) {                      ##
  p <- VlnPlot(obj, features = feature, pt.size = pt.size, ... ) +                                                                ##
    xlab("") + ylab(feature) + ggtitle("") +                                                                                      ##
    theme(legend.position = "none",                                                                                               ##
          axis.text.x = element_blank(),                                                                                          ##
          axis.text.y = element_blank(),                                                                                          ##
          axis.ticks.x = element_blank(),                                                                                         ##
          axis.ticks.y = element_line(),                                                                                          ##
          axis.title.y = element_text(size = rel(1), angle = 0, vjust = 0.5),                                                     ##
          plot.margin = plot.margin )                                                                                             ##
  return(p)                                                                                                                       ##
}                                                                                                                                 ##
## main function                                                                                                                  ##
StackedVlnPlot <- function(obj, features, pt.size = 0, plot.margin = unit(c(-0.75, 0, -0.75, 0), "cm"), ...) {                    ##
  plot_list <- purrr::map(features, function(x) modify_vlnplot(obj = obj,feature = x, ...))                                       ##
  plot_list[[length(plot_list)]]<- plot_list[[length(plot_list)]] +                                                               ##
    theme(axis.text.x=element_text(), axis.ticks.x = element_line())                                                              ##
  p <- patchwork::wrap_plots(plotlist = plot_list, ncol = 1)                                                                      ##
  return(p)                                                                                                                       ##
}                                                                                                                                 ##
my36colors <- c('#E5D2DD', '#53A85F', '#F1BB72', '#F3B1A0', '#D6E7A3', '#57C3F3', '#476D87',                                      ##
                '#E95C59', '#E59CC4', '#AB3282', '#23452F', '#BD956A', '#8C549C', '#585658',                                      ##
                '#9FA3A8', '#E0D4CA', '#5F3D69', '#C5DEBA', '#58A4C3', '#E4C755', '#F7F398',                                      ##
                '#AA9A59', '#E63863', '#E39A35', '#C1E6F3', '#6778AE', '#91D0BE', '#B53E2B',                                      ##
                '#712820', '#DCC1DD', '#CCE0F5', '#CCC9E6', '#625D9E', '#68A180', '#3A6963',                                      ##
                '#968175')                                                                                                        ##
####################################################################################################################################
################################################draw violin figure #################################################################
pdf(file = paste("pancancer_all_focusgenes_distribution_stacked2",".pdf",sep = ""),width = 15,height = 12)                        ##
StackedVlnPlot(pancancer_all, marker_show, pt.size = 0,cols=my36colors) #pt.size=0,??????                                         ##
dev.off()                                                                                                                         ##
####################################################################################################################################
######################################## infercnv data prepare #####################################################################
aa<-pancancer_all@assays$RNA[,]                                                                                                   ##
aa<-as.matrix(aa)                                                                                                                 ##
saveRDS(aa,"exp_matrix.rds")                                                                                                      ##
cellannotation<-pancancer_all@active.ident                                                                                        ##
cellannotation<-as.matrix(cellannotation)                                                                                         ##
write.table(cellannotation,"cellannotation.txt",sep = "\t")                                                                       ##
####################################################################################################################################
################################# cell cancer type & sample type statistic #########################################################
type.orig.ident2<-plyr::mapvalues(x = type.orig.ident, from = "EGC", to = "IGC")                                                  ##
pancancer_all@meta.data$cancertype<-as.matrix(type.orig.ident2)                                                                   ##
bar_all<-cbind(pancancer_all@meta.data$celltype,pancancer_all@meta.data$sampletype,                                               ##
               pancancer_all@meta.data$cancertype,pancancer@meta.data$cancertype2)                                                ##
celltype_list<-levels(celltype.ident)                                                                                             ##
for (i in 1:9) {                                                                                                                  ##
  sign<-table(bar_all[bar_all[,1]==celltype_list[i],3])#2for sample type; 3 for cancer type; 4 for cancer type2                   ##
  singletype_table<-cbind(rep(celltype_list[i],7),rownames(sign),as.matrix(sign))                                                 ##
  rownames(singletype_table)<-NULL                                                                                                ##
  if (i==1) {                                                                                                                     ##
    table_type<-singletype_table                                                                                                  ##
  }else{                                                                                                                          ##
    table_type<-rbind(table_type,singletype_table)                                                                                ##
  }                                                                                                                               ##
}                                                                                                                                 ##
colnames(table_type)<-c("Celltype","Cancertype","Cellnumber")                                                                     ##
table_cancer_type_all<-as.data.frame(table_type)                                                                                  ##
table_cancer_type_all$Cancertype<-as.factor(table_cancer_type_all$Cancertype)                                                     ##
table_cancer_type_all$Cellnumber<-as.numeric(as.matrix(table_cancer_type_all$Cellnumber))                                         ##
p_bar<-ggplot(table_cancer_type_all,aes(x=Celltype,y=Cellnumber,fill=Cancertype))+geom_bar(stat = "identity")+theme_bw()          ##
ggsave("pancancer_cancer_type_count.pdf", p_bar, width=10 ,height=12)                                                             ##
ce<-ddply(table_cancer_type_all,"Celltype",transform,percent_weight=Cellnumber/sum(Cellnumber)*100)                               ##
p_bar2<-ggplot(ce,aes(x=Celltype,y=percent_weight,fill=Cancertype))+geom_bar(stat = "identity")+theme_bw()+coord_flip()           ##
ggsave("pancancer_cancer_type_percent.pdf", p_bar2, width=10 ,height=8)                                                           ##
# for sample                                                                                                                      ##
for (i in 1:9) {                                                                                                                  ##
  sign<-table(bar_all[bar_all[,1]==celltype_list[i],2])#2for sample type; 3 for cancer type                                       ##
  singletype_table<-cbind(rep(celltype_list[i],7),rownames(sign),as.matrix(sign))                                                 ##
  rownames(singletype_table)<-NULL                                                                                                ##
  if (i==1) {                                                                                                                     ##
    table_type<-singletype_table                                                                                                  ##
  }else{                                                                                                                          ##
    table_type<-rbind(table_type,singletype_table)                                                                                ##
  }                                                                                                                               ##
}                                                                                                                                 ##
colnames(table_type)<-c("Celltype","Cancertype","Cellnumber")                                                                     ##
table_sample_type<-as.data.frame(table_type)                                                                                      ##
table_sample_type$Cancertype<-as.factor(table_sample_type$Cancertype)                                                             ##
table_sample_type$Cellnumber<-as.numeric(as.matrix(table_sample_type$Cellnumber))                                                 ##
p_bar<-ggplot(table_sample_type,aes(x=Celltype,y=Cellnumber,fill=Cancertype))+geom_bar(stat = "identity")+theme_bw()              ##
ggsave("pancancer_sample_count.pdf", p_bar, width=10 ,height=12)                                                                  ##
ce<-ddply(table_sample_type,"Celltype",transform,percent_weight=Cellnumber/sum(Cellnumber)*100)                                   ##
p_bar2<-ggplot(ce,aes(x=Celltype,y=percent_weight,fill=Cancertype))+geom_bar(stat = "identity")+theme_bw() #coord_flip()          ##
ggsave("pancancer_sample_percent.pdf", p_bar2, width=10 ,height=8)                                                                ##
####################################################################################################################################
###################################### csc #########################################################################################
#cancer stem cell                                                                                                                 ##
setwd("./sub/cancerstemcell")                                                                                                     ##
csc<-subset(x=pancancer_all,idents="Cancer Stem cell")                                                                            ##
csc_type.ident<-csc@meta.data$study                                                                                               ##
now<-unique(csc_type.ident)                                                                                                       ##
new<-c(rep("HNSCC",10),rep("EC",4),rep("GC",10))                                                                                  ##
csc_type.ident<-plyr::mapvalues(x = csc_type.ident, from = now, to = new)                                                         ##
names(csc_type.ident)<-names(csc$Tissue)                                                                                          ##
csc@meta.data$study<-csc_type.ident                                                                                               ##
csc_type.ident<-as.factor(csc_type.ident)                                                                                         ##
csc@active.ident<-csc_type.ident                                                                                                  ##
csc.list <- SplitObject(csc, split.by = "study")                                                                                  ##
csc.anchors <- FindIntegrationAnchors(object.list = csc.list, dims = 1:40,                                                        ##
                                      k.anchor = 5,k.filter = 20)                                                       ##
csc <- IntegrateData(anchorset = csc.anchors, dims = 1:40)                                                                        ##
csc <- ScaleData(csc, features = all.genes)                                                                                       ##
csc <- RunPCA(object = csc,npcs=50)                                                                                               ##
pdf(file = "csc_pca_use.pdf")                                                                                                     ##
ElbowPlot(csc, ndims = 50)                                                                                                        ##
dev.off()                                                                                                                         ##
csc <- JackStraw(object = csc,dims=50, num.replicate = 50)                                                                        ##
csc <- ScoreJackStraw(object = csc, dims = 1:50)                                                                                  ##
figure_name8<-paste("csc_jackstraw",".pdf",sep = "")                                                                              ##
pdf(file = figure_name8,width = 15,height = 10)                                                                                   ##
JackStrawPlot(object = csc, dims = 1:50)                                                                                          ##
dev.off()                                                                                                                         ##
####################################################################################################################################
########################################  csc tsne   ###############################################################################
pcause=50                                                                                                                         ##
csc_cancertype.ident<-as.factor(csc@meta.data$cancertype)                                                                         ##
now<-levels(csc_cancertype.ident)                                                                                                 ##
new<-c("GC","EC","EC","HNSCC","GC","GC")                                                                                          ##
csc_cancertype.ident<-plyr::mapvalues(x = csc_cancertype.ident, from = now, to = new)                                             ##
#save.SNN = T saves the SNN so that the clustering algorithm can be rerun using the same graph but with a different resolution    ##
csc <- FindNeighbors(object = csc, dims = 1:pcause)                                                                               ##
csc <- FindClusters(object = csc, resolution = 0.1)                                                                               ##
csc <- RunTSNE(object = csc, dims = 1:pcause)                                                                                     ##
pdf(file = paste("csc_tsne_cluster3",pcause,".pdf",sep = ""),width = 8,height = 6)                                                ##
TSNEPlot(object = csc,label = T,pt.size = 1.5)                                                                                    ##
dev.off()                                                                                                                         ##
csc_cluster.ident<-csc@active.ident                                                                                               ##
csc@active.ident<-csc_cancertype.ident                                                                                            ##
figure_name10<-paste("csc_tsne_sample2",".pdf",sep = "")                                                                          ##
pdf(file = figure_name10,width = 12,height = 8)                                                                                   ##
DimPlot(object = csc,reduction = "tsne",group.by = "ident",pt.size = 1.5)                                                         ##
dev.off()                                                                                                                         ##
# tsne for sample                                                                                                                 ##
csc$sampletype<-as.factor(csc$sampletype)                                                                                         ##
pdf(file = "csc_tsne_sampletype.pdf",width = 12,height = 8)                                                                       ##
DimPlot(object = csc,reduction = "tsne",group.by = "sampletype",pt.size = 1.5)                                                    ##
dev.off()                                                                                                                         ##
####################################################################################################################################
##################################### csc each cluster marker ######################################################################
csc.celltype_diff <- FindAllMarkers(object = csc, only.pos = F)                                                                   ##
csc.celltype_diff %>% group_by(cluster) %>% top_n(20, avg_logFC)                                                                  ##
write.csv(csc.celltype_diff,"csc_cancertype_diffgene.csv") #                                                                      ##
csc@active.ident<-csc_cluster.ident                                                                                               ##
csc.clustermarker <- FindAllMarkers(object = csc, only.pos = F)                                                                   ##
csc.clustermarker %>% group_by(cluster) %>% top_n(10, avg_logFC) -> top10                                                         ##
pdf(file = "csc_heatmap_cluster.pdf",width = 14,height = 12)                                                                      ##
DoHeatmap(object = csc, features = top10$gene, label = TRUE,group.bar= T)+                                                        ##
  scale_fill_gradientn(colors = c("white","white","red"))#                                                                ##
dev.off()                                                                                                                         ##
write.csv(csc.clustermarker,"csc_clustermarker_updown.csv") #cluster0                                                             ##
csc.clustermarker2 <- FindAllMarkers(object = csc, only.pos = T)                                                                  ##
write.csv(csc.clustermarker2,"csc_clustermarker_up.csv") #cluster0_only POS
csc_bar_all<-cbind(as.matrix(csc_cluster.ident),as.matrix(csc_cancertype.ident),csc@meta.data$sampletype)                         ##
csc_celltype_list<-levels(csc_cluster.ident)                                                                                      ##
# for cancertype                                                                                                                  ##
for (i in 1:6) {                                                                                                                  ##
  sign<-table(csc_bar_all[csc_bar_all[,1]==csc_celltype_list[i],2]) #2for cancertype 3for sampletype                              ##
  singletype_table<-cbind(rep(csc_celltype_list[i],7),rownames(sign),as.matrix(sign))                                             ##
  rownames(singletype_table)<-NULL                                                                                                ##
  if (i==1) {                                                                                                                     ##
    table_type<-singletype_table                                                                                                  ##
  }else{                                                                                                                          ##
    table_type<-rbind(table_type,singletype_table)                                                                                ##
  }                                                                                                                               ##
}                                                                                                                                 ##
colnames(table_type)<-c("Celltype","Cancertype","Cellnumber")                                                                     ##
table_cancer_type<-as.data.frame(table_type)                                                                                      ##
table_cancer_type$Cancertype<-as.factor(table_cancer_type$Cancertype)                                                             ##
table_cancer_type$Cellnumber<-as.numeric(as.matrix(table_cancer_type$Cellnumber))                                                 ##
p_bar<-ggplot(table_cancer_type,aes(x=Celltype,y=Cellnumber,fill=Cancertype))+geom_bar(stat = "identity")+theme_bw()              ##
ggsave("csc_cancertype_count.pdf", p_bar, width=10 ,height=12)                                                                    ##
ce<-ddply(table_cancer_type,"Celltype",transform,percent_weight=Cellnumber/sum(Cellnumber)*100)                                   ##
p_bar2<-ggplot(ce,aes(x=Celltype,y=percent_weight,fill=Cancertype))+geom_bar(stat = "identity")+theme_bw()                        ##
ggsave("csc_cancertype_count_percent.pdf", p_bar2, width=10 ,height=8)                                                            ##
# for sampletype                                                                                                                  ##
for (i in 1:6) {                                                                                                                  ##
  sign<-table(csc_bar_all[csc_bar_all[,1]==csc_celltype_list[i],3]) #2for cancertype 3for sampletype                              ##
  singletype_table<-cbind(rep(csc_celltype_list[i],7),rownames(sign),as.matrix(sign))                                             ##
  rownames(singletype_table)<-NULL                                                                                                ##
  if (i==1) {                                                                                                                     ##
    table_type<-singletype_table                                                                                                  ##
  }else{                                                                                                                          ##
    table_type<-rbind(table_type,singletype_table)                                                                                ##
  }                                                                                                                               ##
}                                                                                                                                 ##
colnames(table_type)<-c("Celltype","Cancertype","Cellnumber")                                                                     ##
table_sample_type<-as.data.frame(table_type)                                                                                      ##
table_sample_type$Cancertype<-as.factor(table_sample_type$Cancertype)                                                             ##
table_sample_type$Cellnumber<-as.numeric(as.matrix(table_sample_type$Cellnumber))                                                 ##
p_bar<-ggplot(table_sample_type,aes(x=Celltype,y=Cellnumber,fill=Cancertype))+geom_bar(stat = "identity")+theme_bw()              ##
ggsave("csc_sampletype_count.pdf", p_bar, width=10 ,height=12)                                                                    ##
ce<-ddply(table_sample_type,"Celltype",transform,percent_weight=Cellnumber/sum(Cellnumber)*100)                                   ##
p_bar2<-ggplot(ce,aes(x=Celltype,y=percent_weight,fill=Cancertype))+geom_bar(stat = "identity")+theme_bw()                        ##
ggsave("csc_sampletype_count_percent.pdf", p_bar2, width=10 ,height=8)                                                            ##
################################ cluster0 ##########################################################################################
# use cluster0                                                                                                                    ##
csc_cluster0<-subset(x=csc,idents=0)                                                                                              ##
csc_type.ident<-csc@meta.data$study                                                                                               ##
csc_cluster0.list<-SplitObject(csc, split.by = "study")                                                                           ##
csc_typelist<-as.matrix(unique(csc_type.ident))                                                                                   ##
for (i in 1:3) {                                                                                                                  ##
  single_csc<-csc_cluster0.list[[i]]                                                                                              ##
  exp_gene_list<-rownames(single_csc@assays$RNA)[rowMeans(single_csc@assays$RNA)>2]                                               ##
  print(length(exp_gene_list))                                                                                                    ##
  write.csv(exp_gene_list,paste("csc_cluster0_",csc_typelist[i],"_exp_list.csv",sep = ""))                                        ##
}                                                                                                                                 ##
data2<-csc_cluster0@assays$RNA                                                                                                    ##
data3<-as.matrix(data2[1:nrow(data2),1:ncol(data2)])                                                                              ##
write.csv(data3,"csc_cluster0_matrix.csv")                                                                                        ##
cluster0list<-read.csv("/export/home/lileijie/pan_cancer/escc/data/sub/cancerstemcell/csc_cluster0_updowngene.csv")               ##
csc_cluster0_updownexp<-data3[rownames(data3)%in%cluster0list$gene,]                                                              ##
################################# cluster0 in patient ##############################################################################
# patient                                                                                                                         ##
# csc_cluster0@meta.data$sampletype                                                                                               ##
csc_cluster0_samplemap<-matrix(0,length(unique(pancancer_all$sampletype)),2)                                                      ##
rownames(csc_cluster0_samplemap)<-unique(pancancer_all$sampletype)                                                                ##
colnames(csc_cluster0_samplemap)<-c("cluster0","remark")                                                                          ##
csc_cluster0_sample_table<-table(csc_cluster0$sampletype)                                                                         ##
for (i in 1:length(csc_cluster0_sample_table)) {                                                                                  ##
  csc_cluster0_samplemap[rownames(csc_cluster0_samplemap)==names(csc_cluster0_sample_table)[i],1]<-csc_cluster0_sample_table[i]   ##
}                                                                                                                                 ##
write.csv(csc_cluster0_samplemap,"csc_cluster0_samplemap.csv")                                                                    ##
################################ why cluster0 ######################################################################################
#cluster0 is important in all cells compare to each of other celltypes
csc_cluster0
list_except_csc<-levels(pancancer_all@active.ident)[-7]
pancancer_except_csc<-subset(pancancer_all,idents=list_except_csc)
csc_except_c0<-subset(csc,idents=c(1:5))
pancancer_except_cscc0<-merge(x=pancancer_except_csc,y=csc_except_c0)
pancancer_except_cscc0@active.ident<-plyr::mapvalues(x=pancancer_except_cscc0@active.ident,from=c(1:5),to=rep("csc",5))
pancancer_except_cscc0.celltype_diff <- FindAllMarkers(object = pancancer_except_cscc0, only.pos = F)                             ##
pancancer_except_cscc0.celltype_diff <- pancancer_except_cscc0.celltype_diff[abs(pancancer_except_cscc0.celltype_diff$avg_logFC)>1,]
write.csv(x = pancancer_except_cscc0.celltype_diff,file = "pancancer_except_cscc0.celltype_diff.csv")
pancancer_cscc0<-merge(x=pancancer_except_csc,y=csc_cluster0)
pancancer_cscc0@active.ident<-plyr::mapvalues(x=pancancer_cscc0@active.ident,from=0,to="cscc0")
pancancer_cscc0.celltype_diff <- FindAllMarkers(object = pancancer_cscc0, only.pos = F)                                           ##
pancancer_cscc0.celltype_diff <- pancancer_cscc0.celltype_diff[abs(pancancer_cscc0.celltype_diff$avg_logFC)>1,]
write.csv(x = pancancer_cscc0.celltype_diff,file = "pancancer_cscc0.celltype_diff.csv")
pancancer_cscc0.celltype_diff %>% group_by(cluster) %>% top_n(2, avg_logFC) -> test_top2
#cluster0 is special in csc
########################### downsampling EC:GC:HNSCC=19:356:114 ####################################################################
#downsampling to 19:114:114, 77.14%                                                                                               ##
csc_cluster0_random_GC<-sample(1:356,242,replace = F)                                                                             ##
csc_cluster0_gcname<-colnames(csc_cluster0)[csc_cluster0$study=="GC"]                                                             ##
csc_cluster0_usegcname<-csc_cluster0_gcname[csc_cluster0_random_GC]                                                               ##
csc_cluster_reduce_gc<-as.matrix(csc_cluster.ident)                                                                               ##
csc_cluster_reduce_gc[rownames(csc_cluster_reduce_gc)%in%csc_cluster0_usegcname]="10"                                             ##
csc_cluster_reduce_gc<-as.factor(csc_cluster_reduce_gc)                                                                           ##
names(csc_cluster_reduce_gc)<-names(csc_cluster.ident)                                                                            ##
csc@active.ident<-csc_cluster_reduce_gc                                                                                           ##
csc_cluster0_reduce_GC<-subset(x=csc,idents=c(0:5))                                                                               ##
csc@active.ident<-csc_cluster.ident                                                                                               ##
# downsampling figure csc_cluster0_reduce_GC                                                                                      ## 
setwd("./cluster0")                                                                                                               ##
pdf(file = "csc_cluster0_reduce_gc_tsne.pdf",width = 8,height = 6)                                                                ##
TSNEPlot(object = csc_cluster0_reduce_GC,label = T,pt.size = 1.5)                                                                 ##
dev.off()                                                                                                                         ##
csc_cluster0_reduce_gc.celltype_diff <- FindAllMarkers(object = csc_cluster0_reduce_GC, only.pos = F)                             ##
csc_cluster0_reduce_gc.celltype_diff %>% group_by(cluster) %>% top_n(20, avg_logFC)                                               ##
write.csv(csc_cluster0_reduce_gc.celltype_diff,"csc_cluster0_reduce_gc_cancertype_diffgene.csv")                                  ##
#sample                                                                                                                           ##
csc_sample_reduce_gc<-csc_cancertype.ident[names(csc_cancertype.ident)%in%colnames(csc_cluster0_reduce_GC)]                       ##
csc_cluster0_reduce_GC@active.ident<-csc_sample_reduce_gc                                                                         ##
pdf(file = "csc_cluster0_sample_reduce_gc_tsne.pdf",width = 8,height = 6)                                                         ##
DimPlot(object = csc_cluster0_reduce_GC,reduction = "tsne",group.by = "ident",pt.size = 1.5)                                      ##
dev.off()                                                                                                                         ##
####################################################################################################################################
################################################### othercsc #######################################################################
load(file = "/export/home/lileijie/pan_cancer/other_tumor/result_all/other_csc47.RData")                                          ##
setwd("/export/home/lileijie/pan_cancer/escc/data/sub/cancerstemcell/vs_othercsc")                                                ##
# ocsc cancertype                                                                                                                 ##
csc_cancertype_detail.ident<-csc@meta.data$cancertype                                                                             ##
csc@meta.data$cancertype<-csc@meta.data$study                                                                                     ##
csc@meta.data$sample<-csc@meta.data$sampletype                                                                                    ##
csc@meta.data$csctype<-"Gastrointestinal Tumor"                                                                                   ##
ocsc@meta.data$csctype<-"Other Tumor"                                                                                             ##
csc@meta.data$csctype[csc@active.ident==0]<-"Gastrointestinal Tumor Common"                                                       ##
allcsc<-merge(csc,ocsc,add.cell.ids=c("UGC","otherC"))                                                                            ##
allcsc <- CreateSeuratObject(counts = allcsc@assays[["RNA"]]@data,meta.data=allcsc@meta.data)                                     ##
allcsc@meta.data$cancertype2<-allcsc@meta.data$cancertype                                                                         ##
allcsc@meta.data$cancertype2<-plyr::mapvalues(x = allcsc@meta.data$cancertype2, from = c("CRC","EC","GLMC","SCC"), to = rep("MergeC",4))
allcsc.list<-SplitObject(allcsc,split.by="cancertype2")                                                                           ##
for (i in 1:length(allcsc.list)) {                                                                                                ##
  allcsc.list[[i]] <- NormalizeData(allcsc.list[[i]], verbose = F,normalization.method = "LogNormalize")                          ##
  allcsc.list[[i]] <- FindVariableFeatures(object=allcsc.list[[i]],selection.method = "vst",nfeatures = 2000)                     ##
}                                                                                                                                 ##
allcsc.anchors <- FindIntegrationAnchors(object.list = allcsc.list, dims = 1:40,k.anchor = 5,k.filter = 20)                       ##
allcsc <- IntegrateData(anchorset = allcsc.anchors, dims = 1:20,k.weight=50)                                                      ##
allcsc <- ScaleData(allcsc)                                                                                                       ##
allcsc <- RunPCA(object = allcsc,npcs=100)                                                                                        ##
pdf(file = "allcsc_pca_use.pdf")                                                                                                  ##
ElbowPlot(allcsc, ndims = 100)                                                                                                    ##
dev.off()                                                                                                                         ##
####################################################################################################################################
pcause=50                                                                                                                         ##
allcsc <- FindNeighbors(object = allcsc, dims = 1:pcause)                                                                         ##
allcsc <- FindClusters(object = allcsc, resolution = 1.2)                                                                         ##
allcsc <- RunTSNE(object = allcsc, dims = 1:pcause)                                                                               ##
pdf(file = paste("allcsc_tsne_cluster",pcause,".pdf",sep = ""),width = 10,height = 8)                                             ##
TSNEPlot(object = allcsc,label = T)                                                                                               ##
dev.off()                                                                                                                         ##
allcsc_backup<-allcsc                                                                                                             ##
pdf(file = "allcsc_sample50.pdf",width = 10,height = 8)                                                                           ##
DimPlot(object = allcsc,reduction = "tsne",group.by = "cancertype")                                                               ##
dev.off()                                                                                                                         ##
pdf(file = "allcsc_csctype50.pdf",width = 12,height = 8)                                                                          ##
DimPlot(object = allcsc,reduction = "tsne",group.by = "csctype",label=T)                                                          ##
dev.off()                                                                                                                         ##
allcsc@meta.data$clustertype<-allcsc@active.ident                                                                                 ##
allcsc@active.ident[allcsc@active.ident==32]=27                                                                                   ##
allcsc@active.ident[allcsc@active.ident==33]=32                                                                                   ##
pdf(file = "allcsc_clutertype2.pdf",width = 10,height = 8)                                                                        ##
TSNEPlot(object = allcsc,label=T)                                                                                                 ##
dev.off()                                                                                                                         ##
# diff gene calculated                                                                                                            ##
cluster.ident<-allcsc@active.ident                                                                                                ##
allcsc@active.ident<-as.factor(allcsc$csctype)                                                                                    ##
allcsc.celltype_diff <- FindAllMarkers(object = allcsc, only.pos = F)                                                             ##
write.csv(allcsc.celltype_diff,"allcsc_cancertype_diffgenenew.csv") #                                                             ##
####################################################################################################################################
################ cluster0         ##################################################################################################
# original ccsc0                                                                                                                  ##
pancancer_all_original<-merge(x = so_gse10360,y = c(so_srr613,gc_all))                                                            ##
pancancer_all_original@meta.data$csc_split<-0                                                                                     ##
pancancer_all_original@meta.data$csc_split[names(pancancer_all_original$csc_split)%in%names(csc@active.ident)]<-1                 ##
csc_original<-SplitObject(pancancer_all_original,split.by = "csc_split")                                                          ##
csc_original<-csc_original$`1`                                                                                                    ##
csc_original@meta.data$csctype<-"Gastrointestinal Tumor"                                                                          ##
csc_original@meta.data$csctype[names(csc_original$csctype)%in%names(csc_cluster0@active.ident)]<-"Gastrointestinal Tumor Common"  ##
#original ocsc47                                                                                                                  ##
load(file="/export/home/lileijie/pan_cancer/other_tumor/result_all/backup/othercancer_all.RData")                                 ##
setwd("/export/home/lileijie/pan_cancer/escc/data/sub/cancerstemcell/vs_othercsc/run_again/11.11")                                ##
othercancer_all_original<-merge(x=ostc_all,y=c(bc_all,mela1,ovc,scc,glm_all,crc))                                                 ##
othercancer_all_original@meta.data$ocsc47_split<-0                                                                                ##
othercancer_all_original@meta.data$ocsc47_split[names(othercancer_all_original$ocsc47_split)%in%names(ocsc@active.ident)]<-1      ##
ocsc47_original<-SplitObject(othercancer_all_original,split.by = "ocsc47_split")                                                  ##
ocsc47_original<-ocsc47_original$`1`                                                                                              ##
ocsc47_original@meta.data$csctype<-"Other Tumor"                                                                                  ##
csc_original@meta.data$cancertype<-csc@meta.data$cancertype                                                                       ##
allcsc2<-merge(csc_original,ocsc47_original,add.cell.ids=c("UGC","otherC"))                                                       ##
allcsc2@meta.data$cancertype2<-allcsc2@meta.data$cancertype                                                                       ##
allcsc2@meta.data$cancertype2<-plyr::mapvalues(x = allcsc2@meta.data$cancertype2, from = c("CRC","EC","GLMC","SCC"), to = rep("MergeC",4))
allcsc2.list<-SplitObject(allcsc2,split.by="cancertype2")                                                                         ##
for (i in 1:length(allcsc2.list)) {                                                                                               ##
  allcsc2.list[[i]] <- NormalizeData(allcsc2.list[[i]], verbose = F,normalization.method = "LogNormalize")                        ##
  allcsc2.list[[i]] <- FindVariableFeatures(object=allcsc2.list[[i]],selection.method = "vst",nfeatures = 2000)                   ##
}                                                                                                                                 ##
allcsc2.anchors <- FindIntegrationAnchors(object.list = allcsc2.list, dims = 1:40,k.anchor = 5,k.filter = 20)                     ##
allcsc2 <- IntegrateData(anchorset = allcsc2.anchors, dims = 1:20,k.weight=50)                                                    ##
allcsc2 <- ScaleData(allcsc2)                                                                                                     ##
allcsc2 <- RunPCA(object = allcsc2,npcs=100)                                                                                      ##
pdf(file = "allcsc2_pca_use.pdf")                                                                                                 ##
ElbowPlot(allcsc2, ndims = 100)                                                                                                   ##
dev.off()                                                                                                                         ##
####################################################################################################################################
pcause=100                                                                                                                        ##
allcsc2 <- FindNeighbors(object = allcsc2, dims = 1:pcause)                                                                       ##
allcsc2 <- FindClusters(object = allcsc2, resolution = 1.2)                                                                       ##
allcsc2 <- RunTSNE(object = allcsc2, dims = 1:pcause)                                                                             ##
pdf(file = paste("allcsc2_tsne_cluster",pcause,".pdf",sep = ""),width = 10,height = 8)                                            ##
TSNEPlot(object = allcsc2,label = T)                                                                                              ##
dev.off()                                                                                                                         ##
allcsc2_backup<-allcsc2                                                                                                           ##
pdf(file = paste("allcsc2_sample",pcause,".pdf",sep=""),width = 10,height = 8)                                                    ##
DimPlot(object = allcsc2,reduction = "tsne",group.by = "cancertype")                                                              ##
dev.off()                                                                                                                         ##
pdf(file =paste("allcsc2_csctype",pcause,".pdf",sep=""),width = 12,height = 8)                                                    ##
DimPlot(object = allcsc2,reduction = "tsne",group.by = "csctype",label=F)                                                         ##
dev.off()                                                                                                                         ##
allcsc2@meta.data$clustertype<-allcsc2@active.ident                                                                               ##
# diff gene calculated                                                                                                            ##
cluster.ident2<-allcsc2@active.ident                                                                                              ##
allcsc2@active.ident<-as.factor(allcsc2$csctype)                                                                                  ##
allcsc2.celltype_diff <- FindAllMarkers(object = allcsc2, only.pos = F)                                                           ##
write.csv(allcsc2.celltype_diff,"allcsc2_cancertype_diffgenenew.csv")                                                             ##
####################################################################################################################################
save.image(file="pancancer_othercancer_all_2021.11.11.RData")
## GSEA data prepare
write.table(x=allcsc@assays$integrated[,],file="Allcsc_exp_integrated.txt",sep="\t")
csctype_case.control<-allcsc2$csctype
now<-c("Gastrointestinal Tumor Common","Gastrointestinal Tumor","Other Tumor")
csctype_case.control<-plyr::mapvalues(x = csctype_case.control, from = now, to = c("case","control","control")) 
write.table(x=csctype_case.control,file="allcsc_exp_case.control.cls",sep="\t")